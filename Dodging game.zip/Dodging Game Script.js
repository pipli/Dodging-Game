/** @type {HTMLCanvasElement} */
const canvas = document.getElementById("canvas1");
const ctx = canvas.getContext("2d");
canvas.width = 1000;
canvas.height = 500;
let lastTime = 0;

let bullets = [];
let timeToNextBullet = 0;
let bulletInterval = 500;
let noMoreBullets = false;
let counterTillGiantBullet = 0;
let giantBulletSpawned = false;
let winScreenDrawn = false;
let victoryCounter = 0;

let gameOver = false;
let score = 0;
let level = 1;

const backgroundImage = new Image();
backgroundImage.src = "Images/SkyBackground.jpg";

class Player{
    constructor(){
        this.image = new Image();
        this.image.src = "Images/enemy2.png";
        this.spriteWidth = 266;
        this.spriteHeight = 188;
        this.width = this.spriteWidth/4;
        this.height = this.spriteHeight/4;
        this.x = (canvas.width - this.spriteWidth)/2;
        this.y = (canvas.height - this.spriteHeight)/2;
        this.frame = 0;
        this.frameCounter = 0;
        this.goUp = false;
        this.goDown = false;
        this.goLeft = false;
        this.goRight = false;
    }
    update(deltatime){
        if(this.frameCounter > 10){
            this.frame++;
            this.frameCounter = 0;
        }
        else this.frameCounter++;
        if(this.frame === 6) this.frame = 0;
        if(!gameOver){
            if(player.goLeft === true && player.x > 0){
                player.x -= 2;
            }
            if(player.goRight === true && player.x < canvas.width - this.width){
                player.x += 2;
            }
            if(player.goUp === true && player.y > 0){
                player.y -= 2;
            }
            if(player.goDown === true && player.y < canvas.height - this.height){
                player.y += 2;
            }
        }
    }
    draw(){
        ctx.drawImage(this.image, this.frame * this.spriteWidth, 0, this.spriteWidth, this.spriteHeight, this.x, this.y, this.width, this.height);
    }
}

const player = new Player();

class RightBullet{
    constructor(){
        this.image = new Image();
        this.image.src = "Images/BulletRight.png";
        this.spriteWidth = 460;
        this.spriteHeight = 105;
        this.width = this.spriteWidth/10;
        this.height = this.spriteHeight/10;
        this.x = canvas.width;
        this.y = Math.random() * canvas.height;
        this.markedForDeletion = false;
        this.speed = 3;
    }
    update(deltatime){
        this.x -= this.speed;
        if(this.x < 0 - this.width){
            this.markedForDeletion = true;
            if(!gameOver) score++;
        }
        if(level === 2) this.speed = 4;
        if(level === 6){
            noMoreBullets = true;
            counterTillGiantBullet += deltatime;
            if(counterTillGiantBullet >= 7000 && giantBulletSpawned === false){
                giantBulletSpawned = true;
                this.width = this.spriteWidth*5;
                this.height = this.spriteHeight*5;
                this.x = canvas.width*1.5;
                this.y = (canvas.height - this.height)/2;
                this.speed = 0.7;
                bullets.push(new RightBullet());
            }
            if(this.x < 100 && counterTillGiantBullet >= 15000){
                this.markedForDeletion = true;
            }
        }
    }
    draw(){
        ctx.drawImage(this.image, 0, 0, this.spriteWidth, this.spriteHeight, this.x, this.y, this.width, this.height);
    }
}

class LeftBullet{
    constructor(){
        this.image = new Image();
        this.image.src = "Images/BulletLeft.png";
        this.spriteWidth = 460;
        this.spriteHeight = 105;
        this.width = this.spriteWidth/10;
        this.height = this.spriteHeight/10;
        this.x = 0;
        this.y = Math.random() * canvas.height;
        this.markedForDeletion = false;
        this.speed = 3;
    }
    update(){
        this.x += this.speed;
        if(this.x > canvas.width){
            this.markedForDeletion = true;
            if(!gameOver) score++;
        }
        if(level === 6){
            noMoreBullets = true;
        }
    }
    draw(){
        ctx.drawImage(this.image, 0, 0, this.spriteWidth, this.spriteHeight, this.x, this.y, this.width, this.height);
    }
}

function animate(timeStamp){
    let deltatime = timeStamp - lastTime;
    lastTime = timeStamp;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);
    player.update(deltatime);
    player.draw();
    timeToNextBullet += deltatime;
    if(timeToNextBullet > bulletInterval && !gameOver && level <= 5 && noMoreBullets === false){
        bullets.push(new RightBullet());
        timeToNextBullet = 0;
        if(level === 5) bullets.push(new LeftBullet());
    }
    bullets.forEach(object => object.update(deltatime))
    bullets.forEach(object => object.draw())
    bullets = bullets.filter(object => !object.markedForDeletion)
    bullets.forEach(object => {
        if(object.x < player.x + player.width && object.x + object.width > player.x && object.y < player.y + player.height && object.y + object.height > player.y){
            gameOver = true;
        }
    })
    if(score === 20) level = 2;
    if(score === 40) level = 3;
    if(score === 80) level = 4;
    if(score === 150) level = 5;
    if(score === 300) level = 6;
    if(level === 3) bulletInterval = 250;
    if(level === 4) bulletInterval = 150;
    if(level === 5) bulletInterval = 250;
    drawScore();
    drawLevel();
    requestAnimationFrame(animate);
    if(gameOver){
        player.y += deltatime/5;
    }
    if(gameOver === true) drawGameOver();
    if(bullets.length === 0 && level === 6){
        victoryCounter += deltatime;
        ctx.textAlign = "center";
        ctx.font = "30px Impact";
        ctx.fillStyle = "black";
        if(victoryCounter > 0 && victoryCounter < 7000) ctx.fillText("Well... You've done it...", canvas.width/2, canvas.height/2);
        if(victoryCounter > 7000 && victoryCounter < 15000) ctx.fillText("You've dodged bullets in an unknown place, for an unknown reason...", canvas.width/2, canvas.height/2);
        if(victoryCounter > 15000 && victoryCounter < 25000) ctx.fillText("Tell me now... What do you think you have accomplished?", canvas.width/2, canvas.height/2);
        if(victoryCounter > 25000 && victoryCounter < 35000) ctx.fillText("Is it pride? or guilt? or maybe even true serenity?", canvas.width/2, canvas.height/2);
        if(victoryCounter > 35000) ctx.fillText("Either way, Thanks for playing", canvas.width/2, canvas.height/2);
    }
}
animate(0);

function drawScore(){
    ctx.textAlign = "center";
    ctx.font = "20px Impact";
    ctx.fillStyle = "blue";
    ctx.fillText("Score: " + score, 300, 40);
}

function drawLevel(){
    ctx.textAlign = "center"
    ctx.font = "20px Impact";
    ctx.fillStyle = "red";
    if(level <= 5) ctx.fillText("Level: " + level, 600, 40);
    if(level === 6) ctx.fillText("Level Final", 600, 40);
}

function drawGameOver(){
    ctx.font = "50px Impact"
    ctx.textAlign = "center";
    ctx.fillStyle = "black";
    ctx.fillText("Game Over", canvas.width/2, canvas.height/2);
}

window.addEventListener("keydown", function(e){
    if(e.key === 'a'){
        player.goLeft = true;
    }
    if(e.key === 'd'){
        player.goRight = true;
    }
    if(e.key === 'w'){
        player.goUp = true;
    }
    if(e.key === 's'){
        player.goDown = true;
    }
})
window.addEventListener("keyup", function(e){
    if(e.key === 'a'){
        player.goLeft = false;
    }
    if(e.key === 'd'){
        player.goRight = false;
    }
    if(e.key === 'w'){
        player.goUp = false;
    }
    if(e.key === 's'){
        player.goDown = false;
    }
})